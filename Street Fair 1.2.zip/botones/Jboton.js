// Seleccionamos todos los botones con la clase 'botonAnimado'
const botones = document.querySelectorAll('.botonAnimado');

// Iteramos sobre cada botón para agregar los eventos de ratón
botones.forEach(boton => {
    boton.addEventListener('mouseenter', () => {
        boton.style.transform = 'translateY(-5px)';
    });

    boton.addEventListener('mouseleave', () => {
        boton.style.transform = 'translateY(0)';
    });
});


document.querySelectorAll('.abrirVentana').forEach(function(boton) {
  boton.addEventListener('click', function() {
    var ventanaId = boton.getAttribute('data-ventana');
    var ventana = document.getElementById(ventanaId);
    var fondo = document.getElementById('fondo' + ventanaId.substring(7)); // Elimina 'ventana' de la cadena para obtener el número de fondo
    ventana.style.display = 'block'; // Mostrar la ventana correspondiente
    fondo.style.display = 'block'; // Mostrar el fondo con desenfoque
    setTimeout(function() {
      ventana.classList.add('mostrar');
    }, 50); // Ajustar el tiempo según sea necesario
  });
});

document.querySelectorAll('.cerrar').forEach(function(cerrar) {
  cerrar.addEventListener('click', function() {
    var ventanaId = cerrar.getAttribute('data-ventana');
    var ventana = document.getElementById(ventanaId);
    var fondo = document.getElementById('fondo' + ventanaId.substring(7)); // Elimina 'ventana' de la cadena para obtener el número de fondo
    ventana.classList.remove('mostrar');
    ventana.style.display = 'none'; // Ocultar la ventana
    fondo.style.display = 'none'; // Ocultar el fondo
  });
});

// Agregar un event listener al documento para cerrar la ventana si se hace clic fuera de ella
document.addEventListener('click', function(event) {
  var ventanas = document.querySelectorAll('.ventana');
  var botones = document.querySelectorAll('.abrirVentana');

  ventanas.forEach(function(ventana) {
    if (!ventana.contains(event.target) && !Array.from(botones).some(button => button.contains(event.target))) {
      ventana.style.display = 'none';
      var fondo = document.getElementById('fondo' + ventana.id.substring(7));
      if (fondo) {
        fondo.style.display = 'none'; // Ocultar el fondo
      }
    }
  });
});
